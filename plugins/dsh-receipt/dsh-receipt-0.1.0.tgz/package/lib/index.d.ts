import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ReceiptOptions } from './types.js';
export * from './types.js';
export { canonicalStringify, extractExecutionFacts, sha256, verifyReceipt } from './receipt.js';
export { collectGitSnapshot, isSensitivePath, parseNumstat, parsePorcelainStatus } from './git.js';
export { isSensitiveKey, Redactor, truncateText } from './redaction.js';
export { renderReceiptMarkdown, safeSessionDirectory, writeReceipt } from './writer.js';
export declare const name = "receipt";
export declare const inject: string[];
export interface Config {
    /** Absolute local destination. Defaults at apply time to `$DSH_HOME/receipts` or `~/.dsh/receipts`. */
    outputDir?: string;
    /** Opt in to a bounded, redacted text preview. Complete tool output is never stored. */
    includeOutputPreview?: boolean;
    maxOutputPreviewChars?: number;
    maxCommandChars?: number;
    maxChangedFiles?: number;
    /** Opt in to tracked-file content hashing with a per-file byte cap. Zero disables all content reads. */
    maxHashedFileBytes?: number;
    gitTimeoutMs?: number;
}
export declare const Config: z<Config>;
export declare function resolveOptions(config?: Config): ReceiptOptions;
export declare function apply(ctx: Context, config?: Config): void;
