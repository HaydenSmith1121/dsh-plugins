import type { RedactionReport } from './types.js';
export declare function isSensitiveKey(key: string): boolean;
export interface TruncatedText {
    text: string;
    truncated: boolean;
}
export declare function truncateText(value: string, maxChars: number): TruncatedText;
/** Stateful so one receipt can report exactly what was removed before persistence. */
export declare class Redactor {
    private readonly counts;
    private readonly homePattern;
    private readonly workspacePattern;
    constructor(home?: string, workspace?: string);
    private count;
    private replace;
    redactString(input: string): string;
    redactValue(value: unknown): unknown;
    report(): RedactionReport;
}
