import type { SessionEvent, SessionHeader } from '@deepseek-ai/dsh-session';
import type { ToolExecutionResult } from '@deepseek-ai/dsh-tools';
import type { GitSnapshot, Receipt, ReceiptOptions, ToolExecutionFacts, ToolObservation } from './types.js';
type TurnEndEvent = SessionEvent<'turn/end'>;
export declare function sha256(value: string | Uint8Array): string;
export declare function canonicalStringify(value: unknown): string;
/** Extract only non-content execution facts; canonical tool values are otherwise discarded. */
export declare function extractExecutionFacts(value: unknown): ToolExecutionFacts | undefined;
export declare function observeToolResult(sessionId: string, callId: string, name: string, result: Readonly<ToolExecutionResult>, observedAt?: number): ToolObservation;
export interface BuildReceiptInput {
    header: SessionHeader;
    events: readonly SessionEvent[];
    endEvent: TurnEndEvent;
    observations: ReadonlyMap<string, ToolObservation>;
    git: GitSnapshot;
    options: ReceiptOptions;
    generatedAt?: number;
}
export declare function buildReceipt(input: BuildReceiptInput): Receipt;
export declare function verifyReceipt(receipt: Receipt): boolean;
export {};
