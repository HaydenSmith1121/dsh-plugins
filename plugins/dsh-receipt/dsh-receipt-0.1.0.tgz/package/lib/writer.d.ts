import type { Receipt } from './types.js';
export declare function renderReceiptMarkdown(receipt: Receipt): string;
export declare function safeSessionDirectory(sessionId: string): string;
export interface WrittenReceipt {
    directory: string;
    jsonPath: string;
    markdownPath: string;
}
export declare function writeReceipt(receipt: Receipt, outputDir: string, rawSessionId: string): Promise<WrittenReceipt>;
