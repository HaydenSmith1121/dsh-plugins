import type { GitDiffSummary, GitSnapshot } from './types.js';
interface ParsedStatus {
    path: string;
    previousPath?: string;
    status: string;
}
/** Parse `git status --porcelain=v1 -z`; paths stay byte-for-byte decoded by Node as UTF-8. */
export declare function parsePorcelainStatus(output: string): ParsedStatus[];
interface DiffStat {
    additions?: number;
    deletions?: number;
    binary: boolean;
}
interface ParsedNumstat {
    byPath: Map<string, DiffStat>;
    summary: GitDiffSummary;
}
/** `--no-renames` keeps every numstat record in the simple three-field form. */
export declare function parseNumstat(output: string): ParsedNumstat;
/** Fail closed: these files are never opened, even merely to compute a digest. */
export declare function isSensitivePath(path: string): boolean;
export interface CollectGitOptions {
    maxChangedFiles: number;
    maxHashedFileBytes: number;
    timeoutMs: number;
}
/** Fixed, read-only Git probes. A receipt still succeeds when Git is absent or the cwd is not a repository. */
export declare function collectGitSnapshot(cwd: string | undefined, options: CollectGitOptions): Promise<GitSnapshot>;
export {};
