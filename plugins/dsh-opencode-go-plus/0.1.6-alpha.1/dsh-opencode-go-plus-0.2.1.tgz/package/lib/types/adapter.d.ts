/**
 * The OpenCode Go adapter: one route, one catalog, per-request routing header.
 *
 * Every request to the gateway carries two Harness-owned headers: the
 * attribution User-Agent (`deepseek-harness/<version>`), which pi-ai's client
 * lets request headers override, and `x-opencode-session`, which the gateway
 * requires and uses to route a conversation and share its prompt cache. The
 * header value is the request's session id — stable per conversation, so
 * caching and billing attribution stay correct; a request arriving with no
 * session id gets a fresh random value rather than a shared constant, because
 * a constant would merge unrelated traffic into one cache bucket.
 *
 * Multi-turn correctness rides on the shared pi-ai conversion machinery
 * (`toPiContext` reconstructs provider-native replay state from the session
 * log; `toStreamChunks` maps events to seam chunks), so assistant history,
 * tool calls, and usage land in the session log exactly as the generic pi-ai
 * adapter records them. Image content rides the same machinery: models whose
 * catalog entry declares the image modality convert attachments through the
 * durable attachment service, and every other model refuses image content
 * before any provider I/O.
 *
 * @module dsh-llm-opencode-go/adapter
 */
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, ImageAttachmentAccess, LlmModelInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { AttachmentStore, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import { OpencodeGoCatalog } from './catalog.ts';
import type { OpencodeGoConfig } from './config.ts';
/**
 * The attachment-service bridges one image request reads. Construction-time
 * (context-dependent); the config-dependent policy numbers are merged per
 * request from the current configuration.
 */
export interface OpencodeGoImageAccess {
    /** Resolve the optional durable attachment service at request time. */
    resolveAttachments: () => AttachmentStore | undefined;
    /** Bridge one attachment reference into the current model-tool execution world. */
    resolveImageAccess: (attachments: AttachmentStore, ref: ImageAttachmentRef) => ImageAttachmentAccess | undefined;
}
/** Constructor inputs for {@link OpencodeGoAdapter}. */
export interface OpencodeGoAdapterOptions {
    /**
     * The current configuration, re-read at every operation: a settings write
     * reaches the next request without a restart, and one operation never mixes
     * two configuration generations.
     */
    config: () => OpencodeGoConfig;
    /** Resolve the route's credential per call; missing must fail loud. */
    resolveApiKey: () => Promise<string | undefined>;
    /**
     * Image input machinery; absent refuses image content, which is the posture
     * for direct construction without a durable attachment service behind it.
     */
    imageAccess?: OpencodeGoImageAccess;
    /** Observe the catalog falling back to the curated table. */
    onFallback?: (detail: {
        url: string;
        error: unknown;
        kept: number;
    }) => void;
    /** Observe live ids the catalog cannot route, neither curated nor adapted. */
    onOmitted?: (ids: readonly string[]) => void;
    /** Observe live ids adapted onto the route from their family's sibling. */
    onInferred?: (ids: readonly string[]) => void;
    /** Observe assistant history degrading to provider-neutral conversion. */
    onReplayDegrade?: (reason: string) => void;
}
/**
 * The single route's adapter. The catalog snapshot freezes at each operation,
 * so a refresh between two requests never mixes model generations inside one
 * call.
 */
export declare class OpencodeGoAdapter extends LlmAdapter {
    private readonly options;
    /**
     * One catalog instance per endpoint/refresh pair. A settings write that
     * changes either gets a fresh resolver (and a fresh live-listing fetch) on
     * the next operation; an unchanged configuration keeps its cached snapshot
     * for the whole refresh interval.
     */
    private catalogCache;
    constructor(options: OpencodeGoAdapterOptions);
    /**
     * The catalog resolver for one configuration, rebuilding on the facts it
     * owns. Public for the plugin's discovery registration, which resolves the
     * current configuration the same way the adapter does.
     * @param config - the configuration whose endpoint, auto-discovery switch,
     *   and refresh interval the resolver serves; a change to any of them yields
     *   a fresh resolver.
     * @returns the resolver caching one snapshot per configuration key.
     */
    catalogOf(config: OpencodeGoConfig): OpencodeGoCatalog;
    providerInfo(provider: string): {
        id: string;
        name: string;
    };
    listModels(_provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(_provider: string, model: string, _signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    /** Describe one model: capacities plus the reasoning levels it actually offers. */
    private modelInfo;
    /** Validate an explicit effort against the model's own levels, without clamping. */
    private resolveReasoningLevel;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
