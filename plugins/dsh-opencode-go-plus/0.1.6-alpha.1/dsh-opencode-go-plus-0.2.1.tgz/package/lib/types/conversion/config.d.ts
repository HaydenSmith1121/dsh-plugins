/** Default image budgets, overridable through the adapter configuration. */
export declare const DEFAULT_MAX_REQUEST_IMAGE_BYTES: number;
export declare const DEFAULT_REQUEST_IMAGE_PIXEL_BUDGET: number;
export declare const DEFAULT_REQUEST_IMAGE_MAX_BYTES: number;
