import type { Context } from '@deepseek-ai/cordis';
export declare function registerUsagePill(ctx: Context): void;
