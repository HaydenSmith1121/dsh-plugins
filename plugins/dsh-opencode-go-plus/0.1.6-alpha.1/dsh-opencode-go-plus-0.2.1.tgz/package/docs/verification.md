# Verification

This package redistributes the compiled `lib/` only. There is no source tree, no
`scripts/`, and no `devDependencies` in the tarball, so the baseline's
verification workflow — `npm run typecheck`, `npm test`,
`npm run verify:installed` — cannot run against what you receive. This document
records what was measured on the shipped artefact instead, and how to reproduce it.

Baseline of record: `dsh-opencode-go@0.1.2`. Its own `docs/verification.md`
described its source repository and is not reproduced here.

## Environment

| | |
|---|---|
| Date | 2026-09-17 |
| OS | Windows |
| Node | 24.14.0 |
| dsh | 0.1.6-alpha.1 (alpha channel) |
| pnpm | 12.4.2 |
| Profile | `web`, `DSH_HOME` at its default (`~/.dsh`) |

## What was measured

### 1. Tarball contents

`npm pack --ignore-scripts` yields 31 files and no directory entries:

```sh
tar -tzf dsh-opencode-go-plus-0.2.0.tgz | grep -c 'package/lib/'         # 21
tar -tzf dsh-opencode-go-plus-0.2.0.tgz | grep -c 'cordis.patch.yml'     # 1
tar -tzf dsh-opencode-go-plus-0.2.0.tgz | grep -ciE 'package/LICENSE'    # 1
tar -tzf dsh-opencode-go-plus-0.2.0.tgz | grep -cE 'node_modules|\.env'  # 0
```

### 2. Difference from the baseline

```sh
mkdir -p /tmp/base && tar -xzf dsh-opencode-go-0.1.2.tgz -C /tmp/base
diff -rq /tmp/base/package .
```

Seven paths differ and one is new. `lib/client.js` and the remaining
`lib/types/**` are byte-identical. `lib/index.js` carries every executable change;
the three declaration files only describe the surface those changes add.

### 3. Served catalog

Read through the same value path the settings UI uses —
`ctx.llm.listProviders()` then `ctx.llm.listModels(id)` — mounted as a read-only
probe through the profile patch layer (a plugin inserted with `insert` that dumps
its result to disk and exits). One such run against the live endpoint:

```none
id    = opencode-go
name  = OpenCode Go
count = 38
union-alpha        present
deepseek-v4.1-flash present
```

The plugin's own log lines for that resolution:

```none
llm-opencode-go: route "opencode-go" registered as OpenCode Go
llm-opencode-go: adapted live ids the curated table does not describe onto their
  family's protocol: minimax-m2.5, kimi-k2.5, glm-5, deepseek-flash,
  qwen3.5-plus, mimo-v2-pro, mimo-v2-omni, union-alpha, hy3-preview, grok-4.5
llm-opencode-go: catalog resolved (curated 28, live listing 38, adapted 10, omitted 0, served 38)
```

`union-alpha` appearing in the `adapted` list is the borrowed-adaptation fix
working: the baseline drops that id, because it belongs to a family the curated
table has never seen.

### 4. Coexistence with the baseline

Every configuration below was booted, not reasoned about. "Both installed" means
one profile's `dsh.profile.bundles` lists both `dsh-opencode-go` and
`dsh-opencode-go-plus`.

| Bundles | Profile patch | `dsh web` | Served |
|---|---|---|---|
| baseline only | — | starts | `opencode-go`, 37 models, no `union-alpha` |
| this package only | — | starts | `opencode-go`, **38** models, `union-alpha` present |
| both, baseline first | — | starts | the baseline serves 37; this package logs the collision and goes inert |
| both, this package first | — | **fails, exit 1** | — |
| both | baseline `disabled: true` | starts | `opencode-go`, **38** models |

The fourth row is the baseline's defect, not this package's: it does not catch the
`DUPLICATE_DISCOVERY` thrown by `ctx.llm.registerModelDiscovery()`, and the throw
escapes from the loader's own effect, so the whole tree fails and every unrelated
plugin in the profile goes down with it. Nothing this package does can prevent
that; the remedy is simply not to install both. This package's own contribution is
the third row — it no longer brings the tree down when it loses the race.

### 5. Where the plugin's logs go

Worth knowing before you go looking for that collision warning. cordis'
`LoggerService` registers exactly one exporter by default and it appends to an
in-memory ring buffer of 1000 messages. Nothing forwards to `stdout`. Measured: a
boot whose entire console output was the single line `dsh web: http://127.0.0.1:…`
had four entries sitting in `ctx.logger.buffer`, including the three quoted above.

## Reproducing

```sh
# 1. the tarball
tar -tzf dsh-opencode-go-plus-0.2.0.tgz

# 2. install into a profile
dsh plugin --profile web add /absolute/path/to/dsh-opencode-go-plus-0.2.0.tgz

# 3. the four-step check from the distribution repository this ships in
node scripts/verify.mjs

# 4. the catalog, which verify.mjs does not inspect:
#    mount a read-only probe through the profile patch layer and read
#    ctx.llm.listProviders() + ctx.llm.listModels('opencode-go')
```

Step 4 is the one that answers "is the model list right"; `verify.mjs` only proves
the tree loads. Confirm by **count**: 38 including `union-alpha` is this package,
37 without it is the baseline.

## Remaining limits

- No real paid completion was requested. Catalog resolution, route registration,
  the settings surface, and the collision behaviours were exercised; generation
  and streaming were not.
- Windows only. macOS and Linux are unverified here, though the baseline recorded
  macOS runs of its own source tree.
- Only dsh `0.1.6-alpha.1`. The `@deepseek-ai/*` peer range is an exact pin, so
  other releases are unsupported by construction.
- The desktop shell and the `headless` profile were not exercised.
- The live listing is a moving target: 38 is what the endpoint advertised on
  2026-09-17, and the counts drift as the gateway adds and retires models.
