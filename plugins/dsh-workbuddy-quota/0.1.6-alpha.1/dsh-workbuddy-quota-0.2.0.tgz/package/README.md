# dsh-workbuddy-quota

A DeepSeek Harness overlay with two independent, read-only features:

1. **Credit pill** — WorkBuddy's remaining credits beside the composer's model
   selector.
2. **Token usage page** — how many tokens this harness spent, over selectable
   time ranges, in **Settings → Token usage**.

Neither holds a credential, contacts a provider, or changes model routing.

## The token-usage page

**Where:** the sidebar's settings panel, section **Token usage**.

**What it shows**, for the selected range:

- the **total tokens**, and the four provider-reported buckets behind it
  (uncached input, output, cache read, cache write);
- the **cache-read share**, because on a cached harness it routinely dwarfs
  every other bucket and a bare total reads as alarming without it;
- the number of **model calls** in the range.

**Ranges:** Today / Last 7 days / Last 30 days / All time. Ranges are
inclusive local-calendar windows ending today, so they nest — the 7-day figure
always contains the 1-day figure.

## Where the numbers come from

DSH already records **exact provider-reported token usage** in every session log
under `$DSH_HOME/sessions/`, but exposes it only as a per-session cumulative
figure — which cannot answer "how much did I spend today". This plugin folds
those logs.

The fold deliberately reproduces DSH's own `tokenUsage` projection algorithm
(`@deepseek-ai/dsh-token-meter`) rather than inventing a plausible one, because
a report that disagrees with the framework's own numbers is worse than no
report. Three details are load-bearing:

1. **Last sample wins per step.** A streaming step logs several usage samples
   for the same `(turn, step)`; each *replaces* the previous one. A naive sum
   would overcount a streaming step many times over.
2. **A retry starts a new slot.** `llm/retry-started` closes the current slot
   for its own `(turn, step)`, so a retried attempt *adds* alongside the attempt
   it replaced — it legitimately bills twice.
3. **Both `assistant/message` and `assistant/attempt` carry usage**, the latter
   as the last `usage` chunk in its embedded stream.

`npm run verify:fold` re-derives every session's totals and compares them
against DSH's own persisted projection cache — currently **12/12 byte-exact**.

### Known scope limits

- **Title generation is not counted.** `session/title-llm-request` calls spend
  tokens but log no usage sample, so no fold can see them. DSH's own projection
  has the same blind spot; the report is consistent with the framework, not
  silently different from it.
- **Forked sessions do not re-bill their parent.** A fork's inherited prefix
  (`inheritedEventCount`) is skipped, since those events keep the parent's
  timestamps and are already counted with the parent. DSH's *per-session*
  projection does count them, because it answers a different question ("what
  does this one session's log contain").
- **A failed read is reported, not hidden.** The footer shows how many session
  logs were read, and calls out any that could not be. A partial figure is never
  presented as complete.

## Install

The plugin is registered as a bundle in the profile manifest
(`~/.dsh/profiles/web/package.json`), added to `dsh.profile.bundles`, and linked
via `link:` so the working copy is what runs.

**The host half needs a process restart.** DSH's live reload (`patchReload:
live`) rewrites *client* bundles in place, so the settings page appears
immediately after a rebuild — but the route that reads session logs is
registered by the host half, which is only loaded at startup. Until DSH is
restarted, the page says so explicitly instead of failing with a bare 404.

## Layout

| Path | Role |
| --- | --- |
| `src/index.ts` | Host half: resolves `$DSH_HOME`, mounts the usage route. |
| `src/usage-host.ts` | Host half: session discovery, multi-frame zstd decode, TTL cache, HTTP handler. |
| `src/usage-fold.ts` | Pure fold: one session log → per-day, per-route cells. |
| `src/usage-types.ts` | Shared wire contract, range aggregation, and the untrusted-input parsers. |
| `src/protocol.ts` | WorkBuddy status document parser (credit pill). |
| `src/client/UsageSection.tsx` | The token-usage settings page. |
| `src/client/QuotaPill.tsx` | The credit pill. |
| `src/client/index.ts` | Browser half: registers both seats. |

## Commands

```sh
npm run build            # bundle both halves (esbuild CLI)
npm run typecheck        # tsc, strict
npm test                 # typecheck + smoke + render + host-apply

npm run verify:fold      # fold vs DSH's own persisted projection totals
npm run verify:host      # real scan + route handler + wire contract
npm run verify:install   # the installed profile resolves the new bundle
```

`scripts/probe-live.mjs` additionally asks the **running** server for the
client bundle at the exact content-addressed revision derived from the local
bytes, and calls the usage route — the fastest way to confirm a rebuild was
picked up.
