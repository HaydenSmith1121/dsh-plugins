# 第三方组件声明 / Third-party notices

`dsh-excel-viewer` 自身的代码以 MIT 发布（见 `LICENSE`）。但它**内联分发**了一份第三方
库，因此它的 tarball 不是纯 MIT 代码 —— 这一页把话说清楚。

## SheetJS Community Edition（`xlsx`）

| 项 | 值 |
|---|---|
| 组件 | SheetJS Community Edition（npm 包名 `xlsx`） |
| 版本 | **0.20.3** |
| 版权 | © 2012-present SheetJS LLC |
| 许可 | **Apache License 2.0** |
| 上游 | <https://git.sheetjs.com/SheetJS/sheetjs>　·　主页 <https://sheetjs.com/> |
| 获取方式 | `https://cdn.sheetjs.com/xlsx-0.20.3/xlsx-0.20.3.tgz`（官方 CDN） |
| 许可全文 | <https://www.apache.org/licenses/LICENSE-2.0>　·　包内 `LICENSE` 亦随 npm 包分发 |

### 它是怎么被带进来的（内联，不是依赖）

本仓库的 dsh 浏览器模块表**只**提供 `react` 与 `@deepseek-ai/*`：插件 bundle 里出现
任何别的 `require(...)`，用户打开文件的那一刻就会在浏览器里抛错。所以 SheetJS 不是
运行时依赖，而是**在构建期被内联进 `lib/client.js`**：

```
scripts/build.mjs:  alias { xlsx: node_modules/xlsx/dist/xlsx.full.min.js }
                    ↓ esbuild --bundle --format=cjs（external: react）
lib/client.js       = 包装壳 + SheetJS 浏览器全量构建（含代码页表）+ 本插件代码
```

用的是 SheetJS 官方为浏览器发布的 `dist/xlsx.full.min.js`（该包 `package.json` 的
`unpkg` / `jsdelivr` 字段都指向它），而不是 `xlsx.mjs` —— 后者的代码页表要在运行时
单独加载，而 `.xls`（BIFF8）里的中文正需要它们。

构建脚本在打包后会扫描 `require(...)`，发现平台提供不了的 specifier 就直接失败，
所以“内联漏了”这件事不可能悄悄发出去。

### 为什么是 0.20.3 而不是 npm 上的 0.18.5

`registry.npmjs.org` 上的 `xlsx` 停在 **0.18.5（2022 年）**，作者已把发布迁到自己的
CDN。0.18.5 带有已在后续版本修复的安全问题（原型污染 CVE-2023-30533、ReDoS
CVE-2024-22363），而本插件解析的是**用户文件**，正处在这些问题的触发面上。
因此这里固定官方 CDN 的 0.20.3。

固定到具体版本的写法在 `package.json`：

```json
"devDependencies": {
  "xlsx": "https://cdn.sheetjs.com/xlsx-0.20.3/xlsx-0.20.3.tgz"
}
```

> **注意**：`xlsx` 只出现在 `devDependencies`。安装本插件的用户不需要联网取它，
> 也不会有第二个副本进到 `node_modules` —— 代码已经在 `lib/client.js` 里了。

### Apache-2.0 的合规动作

- **保留版权与许可声明**：SheetJS 的版权头（`/*! xlsx.js (C) 2013-present SheetJS */`）
  在构建时以 `legalComments: 'inline'` 保留在 `lib/client.js` 中，未被剥离。
- **提供许可全文**：Apache-2.0 全文见 <https://www.apache.org/licenses/LICENSE-2.0>；
  上游 npm 包内含 `LICENSE` 正文，本仓库不分发其副本，只在此指向它，避免出现
  “本仓库自行声明他人版权”的错觉。
- **说明改动**：本插件**没有**修改 SheetJS 源码，只做整体内联打包。
- **不声称背书**：本插件是第三方作品，与 SheetJS LLC 无隶属关系，也未获得其背书。

## 本插件自己的归属

`dsh-excel-viewer` 的全部代码（渲染器注册、表格视图、样式、构建与测试脚本）由本仓库
编写，MIT。主仓库的来源登记见
[`dsh-plugins` README 第三节](https://github.com/HaydenSmith1121/dsh-plugins#三插件来源与许可)。
